test()
{
   value=$(du -ms home|awk '{print $1}')
   if [ $value -gt 10 ]
    then
      echo "The usage of home disk is $value""M! Please keep it below 10M."
      echo "The usage of home disk is $value""M! Please keep it below 10M."|
      mail -s "Alert for usage of home disk" san9631455@163.com
      echo "Finish sending email!"
   fi
}
while [ true ]
 do
  test
  sleep 300
 done
