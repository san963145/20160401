export JAVA_HOME=/usr/lib/jvm/java-1.6.0-openjdk-i386
export PATH=$JAVA_HOME/bin:$PATH
export CLASSPATH=.:$JAVA_HOME/lib:$CLASSPATH
java Test 1>log_out.log 2>log_err.log
echo "Run Finished!"
