class Test{
 public static void main(String[] args)
 {
    System.out.println("Stdout.");
    System.err.println("Stderr.");
    int x=2/0;
  }
}
