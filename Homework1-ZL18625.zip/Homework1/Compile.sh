export JAVA_HOME=/usr/lib/jvm/java-1.6.0-openjdk-i386
export PATH=$JAVA_HOME/bin:$PATH
javac Test.java
echo "Compile Finished!"
